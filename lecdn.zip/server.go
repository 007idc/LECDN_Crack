package main

import (
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"encoding/base64"
	"encoding/hex"
	"fmt"
	"log"
	"os"
	"runtime/debug"
	"strings"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/recover"
	"github.com/wenzhenxi/gorsa"
)

var logger *log.Logger

func init() {
	file := "./" + time.Now().Format("2006-01-02 15:04:05") + "_log.txt"
	logFile, err := os.OpenFile(file, os.O_RDWR|os.O_CREATE|os.O_APPEND, 0766)
	if err != nil {
		panic(err)
	}
	logger = log.New(logFile, "[server]", log.LstdFlags|log.Lshortfile|log.LUTC)
}

func errHandler(_ *fiber.Ctx, e interface{}) {
	logger.Println("【Panic】", e, debug.Stack())
	_, _ = os.Stderr.WriteString("init panic") // nolint:errcheck // This will never fail
}

func main() {
	app := fiber.New()
	app.Use(recover.New(recover.Config{
		Next:              nil,
		EnableStackTrace:  true,
		StackTraceHandler: errHandler,
	}))
	app.Get("/ip", func(c *fiber.Ctx) error {
		return c.JSON(fiber.Map{
			"ip": "127.0.0.1",
		})
	})

	app.Post("/authorization", authorization)
	logger.Fatal(app.Listen(":10086"))
}

func authorization(c *fiber.Ctx) error {
	var req request
	if err := c.BodyParser(&req); err != nil || req.LicenseCode == "" || req.SystemToken == "" {
		return c.JSON(fiber.Map{
			"code":    0,
			"message": "Cracked by @goedge233",
			"data":    nil,
		})
	}
	license := calcLicense(req.LicenseCode, req.SystemToken, 3392838427, 9999999)
	logger.Println(req.LicenseCode, req.SystemToken, c.IP())
	return c.JSON(fiber.Map{
		"code":    0,
		"message": "Cracked by @goedge233",
		"data": fiber.Map{
			"result": license,
		},
		"cost":       "114514ms",
		"request-id": "1",
	})
}

func calcLicense(code, token string, endTs, nodes int64) string {
	nodeData := base64.StdEncoding.EncodeToString([]byte(fmt.Sprintf(`{"max_nodes": %d}`, nodes)))
	payload := fmt.Sprintf(`{"uuid":"goedge233","app_name":"LeCDN-Master","app_id":"LeCDN-Master-2023","system_token":"%s","license_code":"%s","ip":"127.0.0.1","domain":"127.0.0.1","data":"%s","last_license_time":1692866840,"last_license_time":%d,"expire_time":%d,"license_status":"Active"}`, token, code, nodeData, endTs, endTs)
	payload, err := gorsa.PriKeyEncrypt(payload, Key)
	if err != nil {
		logger.Println(err)
		return ""
	}
	rsaData, _ := hex.DecodeString(payload)
	caesarData1 := caesar(string(rsaData), -18) 
	aesData := Encrypt(caesarData1, "p4KyUWuo4hJGWr1c", "p4KyUWuo4hJGWr1c")
	var lines []string
	for i := 0; i < len(aesData); i += 48 {
		end := i + 48
		if end > len(aesData) {
			end = len(aesData)
		}
		lines = append(lines, aesData[i:end])
	}
	for k := range lines {
		lines[k] = caesar(lines[k], -11)
		lines[k] = reverseString(lines[k])
	}
	return "-----BEGIN License KEY-----\n" + strings.Join(lines, "\n") + "\n-----END License KEY-----"
}

func caesar(inputString string, offset int) string {
	var result []rune
	for _, char := range inputString {
		if 'a' <= char && char <= 'z' {
			v20 := offset + int(char-'a'+26)
			v21 := v20 % 26
			result = append(result, rune('a'+v21))
		} else if 'A' <= char && char <= 'Z' {
			v22 := offset + int(char-'A'+26)
			v23 := v22 % 26
			result = append(result, rune('A'+v23))
		} else {
			result = append(result, char)
		}
	}
	return string(result)
}

func reverseString(s string) string {
	runes := []rune(s)
	n := len(runes)
	for i := 0; i < n/2; i++ {
		runes[i], runes[n-1-i] = runes[n-1-i], runes[i]
	}
	return string(runes)
}

func Encrypt(plainText string, key string, iv string) string {
	data, err := aesCBCEncrypt([]byte(plainText), []byte(key), []byte(iv))
	if err != nil {
		logger.Println(err)
		return ""
	}

	return base64.StdEncoding.EncodeToString(data)
}

func paddingPKCS7(plaintext []byte, blockSize int) []byte {
	paddingSize := blockSize - len(plaintext)%blockSize
	paddingText := bytes.Repeat([]byte{byte(paddingSize)}, paddingSize)
	return append(plaintext, paddingText...)
}

func aesCBCEncrypt(plaintext []byte, key []byte, iv []byte) ([]byte, error) {
	block, err := aes.NewCipher(key)
	if err != nil {
		return nil, err
	}

	plaintext = paddingPKCS7(plaintext, aes.BlockSize)

	mode := cipher.NewCBCEncrypter(block, iv)
	mode.CryptBlocks(plaintext, plaintext)

	return plaintext, nil
}
